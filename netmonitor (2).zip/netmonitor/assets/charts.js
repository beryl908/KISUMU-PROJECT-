// charts.js - a small line chart with a dashed alert-threshold line (no libraries needed)
function lineChart(canvas, labels, values, threshold) {
  if (!canvas) { return; }
  var dpr = window.devicePixelRatio || 1;
  var w = canvas.clientWidth, h = canvas.clientHeight;
  canvas.width = w * dpr; canvas.height = h * dpr;
  var c = canvas.getContext('2d');
  c.setTransform(dpr, 0, 0, dpr, 0, 0);
  c.clearRect(0, 0, w, h);

  var L = 44, R = 10, T = 12, B = 28;
  var pw = w - L - R, ph = h - T - B;
  function y(v) { return T + ph - (v / 100) * ph; }

  c.font = '12px system-ui, Arial, sans-serif';
  c.textBaseline = 'middle';
  c.textAlign = 'right';
  for (var g = 0; g <= 4; g++) {
    var gv = g * 25, gy = y(gv);
    c.strokeStyle = '#e3e8ee'; c.lineWidth = 1;
    c.beginPath(); c.moveTo(L, gy); c.lineTo(w - R, gy); c.stroke();
    c.fillStyle = '#7a8794'; c.fillText(gv + '%', L - 8, gy);
  }

  // alert threshold
  if (threshold) {
    var ty = y(threshold);
    c.strokeStyle = '#e57373'; c.setLineDash([6, 5]); c.lineWidth = 1.5;
    c.beginPath(); c.moveTo(L, ty); c.lineTo(w - R, ty); c.stroke();
    c.setLineDash([]);
    c.fillStyle = '#c62828'; c.textAlign = 'left';
    c.fillText('Alert threshold ' + threshold + '%', L + 8, ty - 9);
  }

  if (!values || !values.length) {
    c.fillStyle = '#7a8794'; c.textAlign = 'center';
    c.fillText('No data yet', L + pw / 2, T + ph / 2);
    return;
  }

  var n = values.length;
  function x(i) { return n === 1 ? L + pw / 2 : L + (i / (n - 1)) * pw; }
  c.strokeStyle = '#1565c0'; c.lineWidth = 2.5; c.lineJoin = 'round';
  c.beginPath();
  for (var i = 0; i < n; i++) { if (i === 0) { c.moveTo(x(i), y(values[i])); } else { c.lineTo(x(i), y(values[i])); } }
  c.stroke();
  if (n === 1) { c.fillStyle = '#1565c0'; c.beginPath(); c.arc(x(0), y(values[0]), 4, 0, 7); c.fill(); }

  // x labels: first, middle, last
  c.fillStyle = '#7a8794'; c.textBaseline = 'alphabetic';
  var idx = n > 2 ? [0, Math.floor((n - 1) / 2), n - 1] : (n === 2 ? [0, 1] : [0]);
  idx.forEach(function (i, k) {
    c.textAlign = (k === 0 && idx.length > 1) ? 'left' : (k === idx.length - 1 && idx.length > 1 ? 'right' : 'center');
    c.fillText(labels[i], x(i), h - 8);
  });
}
